"""
Paste a clipboard image into the scene as a textured plane.

Resolves a copied image file before falling back to PNG pixels from the macOS
clipboard, saves it next to the .blend (or to ~/Downloads if unsaved), and
creates a plane sized so its long edge
matches the configured target length (default 50 mm), and assigns a
material with a transparent-alpha image-texture shader.

Shader graph:
    UV Map ──► Image Texture (Closest, sRGB, Straight) ──┬─► Mix Shader factor (Alpha)
                                                          ├─► Mix Shader slot 2 (Color)
                                                          │
              Transparent BSDF ──────────────────────────┴─► Mix Shader slot 1
                                                              ▼
                                                         Material Output
"""

import datetime
import logging
import os
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import unquote, urlparse

import bpy
from bpy.props import CollectionProperty, StringProperty
from bpy.types import Operator, OperatorFileListElement
from mathutils import Matrix, Vector

log = logging.getLogger(__name__)


MESH_PLANE_SHADER_DEFAULTS = {
    "shader": "SHADELESS",
    "use_transparency": True,
    "render_method": "BLENDED",
    "interpolation": "Closest",
    "extension": "REPEAT",
}

DROP_ORIENTATION_VIEW = "VIEW"
DROP_ORIENTATION_WORLD_Z = "WORLD_Z"


# ---------------------------------------------------------------------------
# Clipboard read (macOS)
# ---------------------------------------------------------------------------

_IMAGE_EXTENSIONS = {
    ".bmp", ".dds", ".exr", ".gif", ".hdr", ".jpeg", ".jpg",
    ".jp2", ".png", ".psd", ".tga", ".tif", ".tiff", ".webp",
}


def _clipboard_image_file_path() -> str | None:
    """Return a copied image file's path, before asking for rendered pixels.

    Finder advertises both a file URL and image representations. For image
    files, coercing the latter to PNG may yield Finder's generic document icon
    instead of the file contents, so the file URL must take precedence.
    """
    if sys.platform != "darwin":
        return None

    script = r'''
    try
        set fileURL to the clipboard as «class furl»
        return fileURL as text
    on error
        return "NO_FILE"
    end try
    '''
    try:
        proc = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            timeout=5,
            text=True,
        )
    except Exception as exc:
        log.debug("Clipboard file URL read failed: %s", exc)
        return None

    value = (proc.stdout or "").strip()
    if proc.returncode != 0 or not value or value == "NO_FILE":
        return None

    parsed = urlparse(value)
    if parsed.scheme == "file" and parsed.netloc in ("", "localhost"):
        path = unquote(parsed.path)
    elif not parsed.scheme:
        path = value
    else:
        return None

    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.isfile(path):
        return None
    if os.path.splitext(path)[1].casefold() not in _IMAGE_EXTENSIONS:
        return None
    return path

def _read_clipboard_png_to_file(out_path: str) -> bool:
    """Write the macOS clipboard's image (if any) to out_path as PNG.

    A copied image file is read directly so Finder's document-icon PNG is not
    mistaken for its contents. Otherwise AppleScript reads clipboard PNGf
    pixels, which is correct for screenshots and copied image regions.
    """
    if sys.platform != "darwin":
        return False

    source_path = _clipboard_image_file_path()
    if source_path:
        try:
            if os.path.splitext(source_path)[1].casefold() == ".png":
                shutil.copyfile(source_path, out_path)
            else:
                converted = subprocess.run(
                    ["sips", "-s", "format", "png", source_path, "--out", out_path],
                    capture_output=True,
                    timeout=30,
                    text=True,
                )
                if converted.returncode != 0:
                    log.warning(
                        "Clipboard image conversion failed: %s",
                        (converted.stderr or converted.stdout or "").strip(),
                    )
                    return False
            return os.path.getsize(out_path) > 0
        except (OSError, subprocess.SubprocessError) as exc:
            log.warning("Clipboard image file copy failed: %s", exc)
            return False

    script = r'''
    on run argv
    set outFile to POSIX file (item 1 of argv)
    try
        set imgData to the clipboard as «class PNGf»
    on error
        return "NO_IMAGE"
    end try
    try
        set fh to open for access outFile with write permission
        set eof of fh to 0
        write imgData to fh
        close access fh
    on error errMsg
        try
            close access outFile
        end try
        return "WRITE_FAILED: " & errMsg
    end try
    return "OK"
    end run
    '''
    try:
        proc = subprocess.run(
            ["osascript", "-e", script, out_path],
            capture_output=True,
            timeout=10,
            text=True,
        )
        out = (proc.stdout or "").strip()
        if proc.returncode != 0 or out != "OK":
            log.warning(
                "Clipboard read failed: rc=%s out=%r err=%r",
                proc.returncode, proc.stdout, proc.stderr,
            )
            return False
        return os.path.exists(out_path) and os.path.getsize(out_path) > 0
    except Exception as exc:
        log.warning("Clipboard read exception: %s", exc)
        return False


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def _save_dir() -> str:
    blend = bpy.data.filepath
    if blend:
        return os.path.dirname(blend)
    return os.path.expanduser("~/Downloads")


def _unique_path(directory: str, stem: str, ext: str = ".png") -> str:
    base = os.path.join(directory, f"{stem}{ext}")
    if not os.path.exists(base):
        return base
    stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    return os.path.join(directory, f"{stem}_{stamp}{ext}")


# ---------------------------------------------------------------------------
# Plane + material construction
# ---------------------------------------------------------------------------

def _build_plane_material(name: str, image: bpy.types.Image) -> bpy.types.Material:
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    mat.blend_method = 'BLEND'  # respect alpha in viewport

    nt = mat.node_tree
    nodes = nt.nodes
    links = nt.links
    for n in list(nodes):
        nodes.remove(n)

    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (600, 0)

    mix = nodes.new("ShaderNodeMixShader")
    mix.location = (380, 0)

    transparent = nodes.new("ShaderNodeBsdfTransparent")
    transparent.location = (140, 140)

    tex = nodes.new("ShaderNodeTexImage")
    tex.location = (-200, -40)
    tex.image = image
    tex.interpolation = 'Closest'
    tex.projection = 'FLAT'
    tex.extension = 'REPEAT'
    if image.colorspace_settings:
        try:
            image.colorspace_settings.name = 'sRGB'
        except Exception:
            pass
    image.alpha_mode = 'STRAIGHT'

    uv = nodes.new("ShaderNodeUVMap")
    uv.location = (-440, -120)
    uv.uv_map = "UVMap"

    links.new(uv.outputs["UV"], tex.inputs["Vector"])
    links.new(tex.outputs["Alpha"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(tex.outputs["Color"], mix.inputs[2])
    links.new(mix.outputs["Shader"], out.inputs["Surface"])

    return mat


def _create_textured_plane(
    context,
    image: bpy.types.Image,
    long_edge_m: float,
    location: Vector,
    rotation_quat,
):
    """Create a plane mesh sized to image aspect, oriented to the view."""
    img_w, img_h = image.size
    if img_w <= 0 or img_h <= 0:
        raise RuntimeError(f"Image has invalid size: {image.size}")

    if img_w >= img_h:
        plane_w = long_edge_m
        plane_h = long_edge_m * (img_h / img_w)
    else:
        plane_h = long_edge_m
        plane_w = long_edge_m * (img_w / img_h)

    half_w = plane_w * 0.5
    half_h = plane_h * 0.5

    mesh = bpy.data.meshes.new(name=f"{image.name}_plane")
    verts = [
        (-half_w, -half_h, 0.0),
        ( half_w, -half_h, 0.0),
        ( half_w,  half_h, 0.0),
        (-half_w,  half_h, 0.0),
    ]
    faces = [(0, 1, 2, 3)]
    mesh.from_pydata(verts, [], faces)
    mesh.update()

    # UV map: 1:1 with the image, no rotation
    uv_layer = mesh.uv_layers.new(name="UVMap")
    uv_data = uv_layer.data
    # face vertex order is 0,1,2,3 → BL, BR, TR, TL
    uv_data[0].uv = (0.0, 0.0)
    uv_data[1].uv = (1.0, 0.0)
    uv_data[2].uv = (1.0, 1.0)
    uv_data[3].uv = (0.0, 1.0)

    obj = bpy.data.objects.new(name=mesh.name, object_data=mesh)
    obj.location = location
    obj.rotation_mode = 'QUATERNION'
    obj.rotation_quaternion = rotation_quat
    # leave rotation un-applied per spec

    coll = context.collection or context.scene.collection
    coll.objects.link(obj)

    mat = _build_plane_material(name=f"{image.name}_mat", image=image)
    obj.data.materials.append(mat)

    return obj


def _viewport_view_state(context):
    """Pivot + rotation of the *active* 3D viewport — the one the user
    invoked the operator from. Falls back to the largest 3D viewport in
    the window if context.area isn't a 3D viewport (e.g. invoked via menu
    from a different editor).

    Returns (location: Vector, rotation_quat) or (origin, None).

    rv3d.view_rotation rotates view-space axes into world space. View-space
    +Z points toward the viewer (Blender views look down -Z view), so
    setting obj.rotation_quaternion = view_rotation aligns the mesh's
    local +Z with "toward the viewer" in world.
    """
    def _state(area):
        space = area.spaces.active
        rv3d = getattr(space, "region_3d", None)
        if rv3d is None:
            return None
        return rv3d.view_location.copy(), rv3d.view_rotation.copy()

    # 1) Prefer the area that owns the operator invocation
    area = getattr(context, "area", None)
    if area is not None and area.type == 'VIEW_3D':
        s = _state(area)
        if s:
            return s

    # 2) Otherwise pick the largest 3D viewport in the window
    candidates = [
        a for a in context.window.screen.areas if a.type == 'VIEW_3D'
    ]
    candidates.sort(key=lambda a: a.width * a.height, reverse=True)
    for a in candidates:
        s = _state(a)
        if s:
            return s

    return Vector((0.0, 0.0, 0.0)), None


# ---------------------------------------------------------------------------
# Operator
# ---------------------------------------------------------------------------

class NO3D_OT_paste_clipboard_plane(Operator):
    """Paste a clipboard image as a textured plane in the 3D viewport."""
    bl_idname = "no3d.paste_clipboard_plane"
    bl_label = "Paste Clipboard as Plane"
    bl_description = (
        "Read the system clipboard for an image, save it next to the .blend "
        "(or ~/Downloads if unsaved), and create a textured plane sized to "
        "the configured long edge"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        if sys.platform != "darwin":
            self.report({'ERROR'}, "Clipboard image paste only supported on macOS")
            return {'CANCELLED'}

        # Resolve target file path
        save_dir = _save_dir()
        os.makedirs(save_dir, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
        target = _unique_path(save_dir, f"clipboard_paste_{stamp}", ".png")

        # Write to a temp first, then move into place — avoids partial files
        # if osascript fails halfway.
        with tempfile.NamedTemporaryFile(
            prefix="no3d_clip_", suffix=".png", delete=False,
        ) as tmp:
            tmp_path = tmp.name

        try:
            ok = _read_clipboard_png_to_file(tmp_path)
            if not ok:
                self.report(
                    {'ERROR'},
                    "No image on clipboard (or clipboard read failed). "
                    "Copy an image first, then run this again."
                )
                return {'CANCELLED'}
            os.replace(tmp_path, target)
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass

        # Load image into Blender
        try:
            image = bpy.data.images.load(target, check_existing=False)
        except Exception as exc:
            self.report({'ERROR'}, f"Failed to load image: {exc}")
            return {'CANCELLED'}

        # Resolve long-edge size from preferences (value is in millimeters)
        addon = context.preferences.addons.get(__package__)
        long_mm = 50.0
        if addon and hasattr(addon, "preferences"):
            long_mm = float(getattr(addon.preferences, "paste_plane_long_edge_mm", 50.0))

        # Convert mm → scene internal units. Blender internal is always meters,
        # but vertex coords get rendered through scene.unit_settings.scale_length.
        # internal_units = meters / scale_length
        scale_length = context.scene.unit_settings.scale_length or 1.0
        long_m = (long_mm / 1000.0) / scale_length

        # Viewport pose
        view_loc, view_rot = _viewport_view_state(context)
        if view_rot is None:
            from mathutils import Quaternion
            view_rot = Quaternion((1.0, 0.0, 0.0, 0.0))

        try:
            obj = _create_textured_plane(
                context, image, long_m, view_loc, view_rot,
            )
        except Exception as exc:
            log.exception("Plane creation failed")
            self.report({'ERROR'}, f"Plane creation failed: {exc}")
            return {'CANCELLED'}

        # Make the new plane the active selection
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        msg = (
            f"Pasted {image.size[0]}×{image.size[1]} image as plane "
            f"({long_mm:.1f}mm long edge) — saved to {target}"
        )
        print(f"[no3d_asset_developer] {msg}")
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class NO3D_OT_drop_images_as_planes(Operator):
    """Import File Browser image drops using NO3D's mesh-plane defaults."""
    bl_idname = "no3d.drop_images_as_planes"
    bl_label = "Import Images as NO3D Planes"
    bl_description = "Drop images into the 3D View as shadeless mesh planes"
    bl_options = {'REGISTER', 'UNDO'}

    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    files: CollectionProperty(
        type=OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        if not self.files:
            self.report({'ERROR'}, "No image files were dropped")
            return {'CANCELLED'}

        addon = context.preferences.addons.get(__package__)
        orientation = DROP_ORIENTATION_VIEW
        long_mm = 50.0
        if addon and hasattr(addon, "preferences"):
            orientation = getattr(
                addon.preferences, "drop_plane_orientation", DROP_ORIENTATION_VIEW
            )
            long_mm = float(
                getattr(addon.preferences, "paste_plane_long_edge_mm", 50.0)
            )

        view_rotation = None
        if orientation == DROP_ORIENTATION_VIEW:
            _view_location, view_rotation = _viewport_view_state(context)

        objects_before = set(context.scene.objects)
        try:
            result = bpy.ops.image.import_as_mesh_planes(
                'EXEC_DEFAULT',
                directory=self.directory,
                files=[{"name": item.name} for item in self.files],
                align_axis='+Z',
                **MESH_PLANE_SHADER_DEFAULTS,
            )
        except Exception as exc:
            log.exception("Dropped image plane import failed")
            self.report({'ERROR'}, f"Image plane import failed: {exc}")
            return {'CANCELLED'}

        if 'FINISHED' not in result:
            return result

        new_planes = [
            obj for obj in context.scene.objects
            if obj not in objects_before and obj.type == 'MESH'
        ]
        scale_length = context.scene.unit_settings.scale_length or 1.0
        long_edge = (long_mm / 1000.0) / scale_length
        for obj in new_planes:
            current_long_edge = max(obj.dimensions.x, obj.dimensions.y)
            if current_long_edge > 0.0:
                obj.data.transform(Matrix.Scale(long_edge / current_long_edge, 4))
                obj.data.update()

        if view_rotation is not None:
            for obj in new_planes:
                _set_object_rotation_quat(obj, view_rotation)

        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Orient selected objects' +Z to the viewport
# ---------------------------------------------------------------------------

def _set_object_rotation_quat(obj, quat):
    """Write a quaternion into the object's current rotation mode."""
    mode = obj.rotation_mode
    if mode == 'QUATERNION':
        obj.rotation_quaternion = quat
    elif mode == 'AXIS_ANGLE':
        axis, angle = quat.to_axis_angle()
        obj.rotation_axis_angle = (angle, axis.x, axis.y, axis.z)
    else:
        # Euler — preserve the user's chosen order (XYZ, ZYX, etc.)
        obj.rotation_euler = quat.to_euler(mode)


class NO3D_OT_orient_z_to_viewport(Operator):
    """Rotate selected objects so their local +Z faces the viewer."""
    bl_idname = "no3d.orient_z_to_viewport"
    bl_label = "Orient Z to Viewport"
    bl_description = (
        "Rotate every selected object so its local +Z axis points toward "
        "the viewer in the active 3D viewport. Locations are unchanged"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.area is not None
            and context.area.type == 'VIEW_3D'
            and len(context.selected_objects) > 0
        )

    def execute(self, context):
        _, view_quat = _viewport_view_state(context)
        if view_quat is None:
            self.report({'ERROR'}, "No 3D viewport found")
            return {'CANCELLED'}

        targets = list(context.selected_objects)
        if not targets:
            self.report({'INFO'}, "Nothing selected")
            return {'CANCELLED'}

        for obj in targets:
            _set_object_rotation_quat(obj, view_quat)

        n = len(targets)
        msg = f"Oriented +Z to viewport on {n} object{'s' if n != 1 else ''}"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Add menu entry
# ---------------------------------------------------------------------------

def _draw_add_menu(self, context):
    self.layout.separator()
    self.layout.operator(
        "no3d.paste_clipboard_plane",
        text="Paste Clipboard as Plane",
        icon='IMAGE_DATA',
    )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

_classes = (
    NO3D_OT_paste_clipboard_plane,
    NO3D_OT_drop_images_as_planes,
    NO3D_OT_orient_z_to_viewport,
)

_addon_keymaps = []
_native_drop_handler_class = None


class NO3D_FH_drop_images_as_planes(bpy.types.FileHandler):
    bl_idname = "NO3D_FH_drop_images_as_planes"
    bl_label = "Import images as NO3D planes"
    bl_import_operator = "NO3D_OT_drop_images_as_planes"
    bl_file_extensions = ";".join(bpy.path.extensions_image)

    @classmethod
    def poll_drop(cls, context):
        if not context.space_data or context.space_data.type != 'VIEW_3D':
            return False
        return context.space_data.region_3d.view_perspective in {'PERSP', 'ORTHO'}


def _replace_native_image_drop_handler():
    """Replace Blender's viewport image-empty drop while this add-on is on."""
    global _native_drop_handler_class
    try:
        from bl_operators.view3d import VIEW3D_FH_empty_image

        if getattr(VIEW3D_FH_empty_image, "is_registered", False):
            bpy.utils.unregister_class(VIEW3D_FH_empty_image)
            _native_drop_handler_class = VIEW3D_FH_empty_image
        bpy.utils.register_class(NO3D_FH_drop_images_as_planes)
    except Exception:
        log.exception("Could not replace Blender's viewport image drop handler")
        if _native_drop_handler_class is not None:
            try:
                bpy.utils.register_class(_native_drop_handler_class)
            except Exception:
                pass
            _native_drop_handler_class = None


def _restore_native_image_drop_handler():
    global _native_drop_handler_class
    if getattr(NO3D_FH_drop_images_as_planes, "is_registered", False):
        try:
            bpy.utils.unregister_class(NO3D_FH_drop_images_as_planes)
        except RuntimeError:
            pass
    if _native_drop_handler_class is not None:
        try:
            if not getattr(_native_drop_handler_class, "is_registered", False):
                bpy.utils.register_class(_native_drop_handler_class)
        except Exception:
            log.exception("Could not restore Blender's viewport image drop handler")
        finally:
            _native_drop_handler_class = None


def _apply_mesh_plane_shader_defaults(properties):
    """Apply the canonical clipboard-plane shader choices to operator props."""
    for name, value in MESH_PLANE_SHADER_DEFAULTS.items():
        setattr(properties, name, value)


def _seed_native_mesh_plane_defaults():
    """Make Add → Image → Mesh Plane open with NO3D's shader template."""
    try:
        properties = bpy.context.window_manager.operator_properties_last(
            "image.import_as_mesh_planes"
        )
        if properties is not None:
            _apply_mesh_plane_shader_defaults(properties)
    except Exception as exc:
        log.warning("Could not seed Image as Mesh Plane defaults: %s", exc)
    return None


def _register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc is None:
        return
    km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")

    # Cmd+Shift+V — paste clipboard as plane
    kmi = km.keymap_items.new(
        "no3d.paste_clipboard_plane",
        type="V", value="PRESS",
        oskey=True, shift=True,
    )
    _addon_keymaps.append((km, kmi))

    # Shift+5 — native Image → Mesh Plane importer with the same shadeless
    # alpha material defaults as Paste Clipboard as Plane.
    kmi = km.keymap_items.new(
        "image.import_as_mesh_planes",
        type="FIVE", value="PRESS",
        shift=True,
    )
    _apply_mesh_plane_shader_defaults(kmi.properties)
    _addon_keymaps.append((km, kmi))

    # Ctrl+Shift+Alt+Z — orient selected objects' +Z to viewport
    kmi = km.keymap_items.new(
        "no3d.orient_z_to_viewport",
        type="Z", value="PRESS",
        ctrl=True, shift=True, alt=True,
    )
    _addon_keymaps.append((km, kmi))


def _unregister_keymaps():
    for km, kmi in _addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _addon_keymaps.clear()


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    _replace_native_image_drop_handler()
    _register_keymaps()
    _seed_native_mesh_plane_defaults()
    try:
        bpy.types.VIEW3D_MT_image_add.append(_draw_add_menu)
    except Exception:
        # In Blender 5.x the image submenu may have a different name; fall
        # back to the top-level Add menu.
        try:
            bpy.types.VIEW3D_MT_add.append(_draw_add_menu)
        except Exception as exc:
            log.warning("Could not append to Add menu: %s", exc)


def unregister():
    for menu_name in ("VIEW3D_MT_image_add", "VIEW3D_MT_add"):
        menu_cls = getattr(bpy.types, menu_name, None)
        if menu_cls is not None:
            try:
                menu_cls.remove(_draw_add_menu)
            except Exception:
                pass
    _unregister_keymaps()
    _restore_native_image_drop_handler()
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
