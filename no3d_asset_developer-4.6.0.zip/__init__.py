bl_info = {
    "name": "No3d Asset Developer",
    "author": "NO3D Tools",
    "version": (4, 6, 0),
    "blender": (5, 0, 0),
    "location": "Asset Browser > Context Menu | 3D Viewport > N-Panel > NO3D Dev",
    "description": "Export marked assets as clean, individual .blend files with frontmatter, thumbnails, and dev notes. WIP folder auto-sync.",
    "category": "Asset",
    "doc_url": "",
    "tracker_url": "",
}

import datetime
import json
import os

import bpy
from bpy.types import AddonPreferences
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    StringProperty,
)
from . import aspect_overlay
from . import stowaway_inspector
from . import clipboard_paste
from . import repo_registration
from . import saved_file_views
from . import editor_screenshot
from . import embed_staging
from . import header_screenshots
from . import geonode_object
from . import library_roles
from . import node_screenshot
from . import power_panel
from . import operators
from . import ui
from . import viewport_format
from . import viewport_shortcuts
from . import viewport_screenshot
from . import transparent_media
from . import wip
from . import wip_sync
from . import public_library
from .notes import note_manager


# NOTE: Method A (TEMPLATE_APPEND) is retained in code but no longer exposed in
# the UI — Method B (DATABLOCK_WRITE) is the sole user-facing pipeline. This enum
# is kept so the dispatcher and the console escape hatch still resolve both
# identifiers; the picker was removed from ui.py (see _draw_extract_v3).
EXTRACTION_METHOD_ITEMS = [
    (
        "TEMPLATE_APPEND",
        "Method A — Template Append",
        "Subprocess: opens _export_template.blend, appends the asset, strips smuggled markings, "
        "purges orphans, saves. Preserves scene and METRIC/mm units. Default for production.",
    ),
    (
        "DATABLOCK_WRITE",
        "Method B — Datablock Write",
        "In-process: bpy.data.libraries.write({asset}). Pose-library-native. No subprocess, no "
        "template. Faster. Output has no Scene/units; transitive deps come along.",
    ),
]

VIEW_ALIGN_KEY_ITEMS = tuple(
    (letter, letter, f"Use {letter} while View Distribute is active")
    for letter in "BCDEFGHIJKLMNOPQRSTUVWXYZ"
)


class NO3D_AddonPreferences(AddonPreferences):
    """Add-on preferences for No3d Asset Developer"""
    bl_idname = __name__

    view_align_bounds_reference: EnumProperty(
        name="Edge Alignment Reference",
        items=(
            ("SELECTION", "Selection Bounds", "Align to the combined selected-object bounds"),
            ("ACTIVE", "Active Object", "Align to the active object's matching edge"),
        ),
        default="SELECTION",
    )
    view_distribute_axis_x_key: EnumProperty(
        name="World X Lock", items=VIEW_ALIGN_KEY_ITEMS, default="X"
    )
    view_distribute_axis_y_key: EnumProperty(
        name="World Y Lock", items=VIEW_ALIGN_KEY_ITEMS, default="C"
    )
    view_distribute_axis_z_key: EnumProperty(
        name="World Z Lock", items=VIEW_ALIGN_KEY_ITEMS, default="Z"
    )

    default_vendor: StringProperty(
        name="Default Vendor",
        description="Default vendor name for exported assets",
        default="The Well Tarot",
    )

    default_product_type: StringProperty(
        name="Default Product Type",
        description="Default product type for exported assets",
        default="Blender Add-on",
    )

    export_library_path: StringProperty(
        name="Export Library Path",
        description="Default export directory for assets",
        subtype='DIR_PATH',
        default="/Users/joebowers/Library/CloudStorage/Dropbox/Caveman Creative/THE WELL_Digital Assets/THE WELL_play files/WIP-Autosave Assets/",
    )

    public_library_path: StringProperty(
        name="Public Product Library",
        description="Canonical local product library; distinct from the WIP autosync library",
        subtype='DIR_PATH',
        default="/Users/joebowers/Library/CloudStorage/Dropbox/Caveman Creative/THE WELL_Digital Assets/The Well Code/solvet-global/no3d-tools-library/library/",
    )

    public_library_name: StringProperty(
        name="Public Library Name",
        description="Display name used for public-library activity and product controls",
        default="NO3D Tools",
    )

    obsidian_library_vault_name: StringProperty(
        name="Obsidian Library Vault",
        description="Obsidian vault name containing the NO3D product library",
        default="no3d-tools-library",
    )

    obsidian_docs_vault_name: StringProperty(
        name="Obsidian Documentation Vault",
        description="Obsidian vault name containing canonical NO3D documentation",
        default="Vault_001",
    )

    obsidian_workbench_path: StringProperty(
        name="Product Workbench Path",
        default="Product Editing workbench.canvas",
    )

    obsidian_catalog_docs_path: StringProperty(
        name="Catalog Workflow Path",
        default="NO3D/docs/Product Catalog and Member Library Workflow.md",
    )

    solvet_repo_path: StringProperty(
        name="SOLVET Repository",
        description="Repository containing the shared preview-first product workflow",
        subtype='DIR_PATH',
        default="/Users/joebowers/Library/CloudStorage/Dropbox/Caveman Creative/THE WELL_Digital Assets/The Well Code/solvet-global/",
    )

    public_auto_stage: BoolProperty(
        name="Auto-stage linked public assets on Save",
        description="Stage local files for already-linked products on save; never publishes remotely",
        default=True,
    )

    node_screenshot_path: StringProperty(
        name="Node Screenshot Folder",
        description=(
            "Where transparent node-editor screenshots are saved. "
            "Empty = current .blend's folder, fall back to ~/Downloads"
        ),
        subtype='DIR_PATH',
        default="",
    )

    thumbnail_margin: FloatProperty(
        name="Thumbnail Margin",
        description=(
            "Outer margin guide for thumbnail capture, as a fraction of the "
            "square's side. 0.25 = inner safe-area is half the outer size."
        ),
        default=0.25,
        min=0.0,
        max=0.49,
        precision=2,
        subtype='FACTOR',
    )

    viewport_screenshot_keep_gizmos: BoolProperty(
        name="Keep Gizmos in Capture",
        description=(
            "When capturing the 3D viewport, keep gizmos (move/rotate/scale "
            "handles, light cones, camera frustums) visible in the output. "
            "Other overlays (grid, cursor, outlines) are still hidden. "
            "Note: OFFSCREEN_* methods cannot show gizmos at all (gizmos "
            "live in screen pixels only) — toggle is a no-op for those."
        ),
        default=False,
    )

    viewport_capture_method: EnumProperty(
        name="Viewport Capture Method",
        description=(
            "How the 3D viewport screenshot is rendered. Each method "
            "trades off transparency, gizmos, HDRI, and resolution differently."
        ),
        items=[
            (
                "RENDER_OPENGL",
                "OpenGL Render (default, sharp, no alpha)",
                "bpy.ops.render.opengl at multiplier resolution. No transparency. Clean and sharp.",
            ),
            (
                "OFFSCREEN_SOLID",
                "Offscreen Solid (sharp + alpha, no gizmos)",
                "GPU offscreen draw_view3d with draw_background=False. Native alpha, no gizmos.",
            ),
            (
                "OFFSCREEN_MATERIAL",
                "Offscreen Material/Rendered (HDRI + alpha)",
                "Same as Offscreen Solid but uses current viewport shading. Some materials may have partial-alpha holes.",
            ),
            (
                "SCREEN_CAPTURE",
                "Screen Capture (HDRI + gizmos, no alpha)",
                "Full-window screenshot cropped to viewport. No transparency. Includes everything you see.",
            ),
            (
                "CRYPTOMATTE_OFFSCREEN_MASK",
                "Cryptomatte Mask + Screen RGB (gizmos + alpha)",
                "Two-pass: flat-white solid mask + screen-capture RGB, composited. Best for transparent thumbnails with gizmos.",
            ),
            (
                "WORLD_SWAP_DIFF",
                "World Swap Difference Matte",
                "Magenta/green world swap, difference-matte extraction. Lower fidelity inside glossy reflections.",
            ),
        ],
        default="RENDER_OPENGL",
    )

    viewport_capture_resolution_multiplier: IntProperty(
        name="Resolution Multiplier",
        description=(
            "Multiply viewport dimensions by this factor for the capture. "
            "2x ~ Retina-sharp; 4x = oversampled. Methods that capture screen "
            "pixels (SCREEN_CAPTURE, WORLD_SWAP_DIFF) ignore this."
        ),
        default=2,
        min=1,
        max=4,
    )

    editor_capture_round_corners: BoolProperty(
        name="Round Outer Corners",
        description=(
            "When capturing an editor area, fade out the corners that touch "
            "the OS window's outer edge so the screenshot matches the macOS "
            "rounded-window look. Inner corners (adjacent to other editors) "
            "stay square"
        ),
        default=True,
    )

    editor_capture_corner_radius: IntProperty(
        name="Corner Radius (px)",
        description=(
            "Radius of the rounded fade at outer corners, in logical pixels. "
            "macOS Sequoia uses ~10 px. Set 0 to disable"
        ),
        default=10,
        min=0,
        max=40,
    )

    paste_plane_long_edge_mm: FloatProperty(
        name="Image Plane Long Edge (mm)",
        description=(
            "When pasting or dropping an image as a plane, the long edge "
            "will be this many millimeters. The short edge is "
            "scaled to preserve the image's aspect ratio. Always millimeters, "
            "regardless of scene length units."
        ),
        default=50.0,
        min=0.1,
        max=10000.0,
        precision=2,
    )

    drop_plane_orientation: EnumProperty(
        name="Dropped Image Orientation",
        description="Orientation used when an image is dragged from Blender's File Browser into the 3D View",
        items=(
            (
                clipboard_paste.DROP_ORIENTATION_VIEW,
                "Face Current View",
                "Face the viewport as it looked when the image was dropped",
            ),
            (
                clipboard_paste.DROP_ORIENTATION_WORLD_Z,
                "World Z Up",
                "Keep the plane flat in world XY with its local Z pointing up",
            ),
        ),
        default=clipboard_paste.DROP_ORIENTATION_VIEW,
    )

    saved_file_views: CollectionProperty(type=saved_file_views.NO3D_FileBrowserSavedView)
    saved_file_views_index: IntProperty(default=0)
    saved_file_views_initialized: BoolProperty(default=False, options={'HIDDEN'})

    transparent_media_ffmpeg_path: StringProperty(
        name="FFmpeg Executable",
        description="Optional FFmpeg executable override; leave empty to auto-detect Homebrew or PATH",
        subtype='FILE_PATH',
        default="",
    )

    # ----- Aspect Overlay -----
    aspect_snap_enabled: BoolProperty(
        name="Magnetic Snap on Resize",
        description=(
            "When you finish dragging an editor edge, snap the result to "
            "the nearest enabled aspect-ratio preset if it's within the "
            "snap threshold"
        ),
        default=True,
    )
    aspect_snap_threshold_px: IntProperty(
        name="Snap Threshold (px)",
        description=(
            "How close (in logical pixels) the resulting area dimension "
            "must be to a preset's exact aspect for the snap to fire. "
            "0 disables"
        ),
        default=12,
        min=0,
        max=50,
    )
    show_preset_9_16: BoolProperty(
        name="Show Portrait 9:16",
        description="Draw the 9:16 preset rectangle in the overlay",
        default=True,
    )
    show_preset_4_5: BoolProperty(
        name="Show Feed 4:5",
        description="Draw the 4:5 preset rectangle in the overlay",
        default=True,
    )
    show_preset_1_1: BoolProperty(
        name="Show Square 1:1",
        description="Draw the 1:1 preset rectangle in the overlay",
        default=True,
    )
    show_preset_16_9: BoolProperty(
        name="Show Landscape 16:9",
        description="Draw the 16:9 preset rectangle in the overlay",
        default=True,
    )
    show_preset_4_3: BoolProperty(
        name="Show Hero/Banner 4:3",
        description=(
            "Draw the 4:3 preset rectangle in the overlay. Product-listing "
            "target: no3dtools Hero / Banner (960×720)"
        ),
        default=True,
    )
    show_preset_og_1_91: BoolProperty(
        name="Show Social/OG 1.91:1",
        description=(
            "Draw the 1.91:1 (1200×630) preset rectangle in the overlay. "
            "Product-listing target: Gumroad & no3dtools Social / OG image"
        ),
        default=True,
    )
    aspect_custom_presets: CollectionProperty(
        type=aspect_overlay.NO3D_AspectCustomPreset,
        name="Custom Aspect Presets",
        description="User-defined aspect-ratio presets",
    )
    aspect_custom_presets_index: IntProperty(
        name="Active Custom Preset",
        default=0,
    )

    aspect_section_snap_expanded: BoolProperty(
        name="Magnetic Snap section expanded",
        default=True,
    )
    aspect_section_builtin_expanded: BoolProperty(
        name="Built-in Presets section expanded",
        default=True,
    )
    aspect_section_custom_expanded: BoolProperty(
        name="Custom Presets section expanded",
        default=True,
    )

    def draw(self, context):
        layout = self.layout

        # Version Information
        box = layout.box()
        box.label(text="Version Information", icon='INFO')
        row = box.row()
        row.label(text=f"Version: {'.'.join(map(str, bl_info['version']))}")
        try:
            mtime = os.path.getmtime(__file__)
            stamp = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
            box.row().label(text=f"Last updated: {stamp}")
        except OSError:
            pass

        layout.separator()

        box = layout.box()
        box.label(text="View Align", icon="MOD_MIRROR")
        box.prop(self, "view_align_bounds_reference")
        row = box.row(align=True)
        row.prop(self, "view_distribute_axis_x_key", text="X")
        row.prop(self, "view_distribute_axis_y_key", text="Y")
        row.prop(self, "view_distribute_axis_z_key", text="Z")
        box.label(text="A toggles zero gap while Distribute is active", icon="INFO")

        layout.separator()

        # Export Defaults
        box = layout.box()
        box.label(text="Export Defaults", icon='EXPORT')
        box.prop(self, "default_vendor")
        box.prop(self, "default_product_type")
        box.prop(self, "export_library_path")
        box.prop(self, "public_library_path")
        box.prop(self, "public_library_name")
        box.prop(self, "obsidian_library_vault_name")
        box.prop(self, "obsidian_docs_vault_name")
        box.prop(self, "obsidian_workbench_path")
        box.prop(self, "obsidian_catalog_docs_path")
        box.prop(self, "solvet_repo_path")
        box.prop(self, "public_auto_stage")

        layout.separator()

        # Node Screenshot
        box = layout.box()
        box.label(text="Node Screenshot", icon='IMAGE_DATA')
        box.prop(self, "node_screenshot_path")
        box.label(
            text="Empty = save next to current .blend (or ~/Downloads if unsaved)",
            icon='INFO',
        )
        box.prop(self, "thumbnail_margin", slider=True)

        layout.separator()

        # Viewport Capture
        box = layout.box()
        box.label(text="Viewport Capture", icon='RESTRICT_RENDER_OFF')
        box.prop(self, "viewport_capture_method", text="Method")
        box.prop(self, "viewport_capture_resolution_multiplier", slider=True)
        box.prop(self, "viewport_screenshot_keep_gizmos")
        box.label(
            text="OFFSCREEN_* methods cannot show gizmos (gizmos live in screen pixels)",
            icon='INFO',
        )

        layout.separator()

        # Editor Screenshot
        box = layout.box()
        box.label(text="Editor Screenshot", icon='WINDOW')
        box.prop(self, "editor_capture_round_corners")
        sub = box.row()
        sub.enabled = self.editor_capture_round_corners
        sub.prop(self, "editor_capture_corner_radius", slider=True)

        layout.separator()

        # Image planes
        box = layout.box()
        box.label(text="Images as Planes", icon='IMAGE_REFERENCE')
        box.prop(self, "paste_plane_long_edge_mm")
        box.prop(self, "drop_plane_orientation")
        box.label(text="File Browser drops use the shadeless NO3D plane settings.", icon='INFO')

        layout.separator()

        box = layout.box()
        box.label(text="Transparent Media", icon='FILE_MOVIE')
        box.prop(self, "transparent_media_ffmpeg_path")
        box.label(text="Leave empty to auto-detect FFmpeg.", icon='INFO')

        layout.separator()

        power_panel.draw_preferences(layout, self)

        layout.separator()

        # Keymap (editable shortcuts)
        box = layout.box()
        box.label(text="Keyboard Shortcuts", icon='KEYINGSET')
        _draw_addon_keymap_items(box, context)

        layout.separator()

        # Update Section
        box = layout.box()
        box.label(text="Update Add-on", icon='FILE_REFRESH')
        box.operator(
            "preferences.addon_update_no3d",
            text="Update Add-on",
            icon='IMPORT'
        )
        box.label(text="Select the latest .zip file to install", icon='INFO')


power_panel.install_preference_properties(NO3D_AddonPreferences)


def _draw_addon_keymap_items(layout, context):
    """Render editable keymap rows for every shortcut this addon binds.

    Uses Blender's bundled `rna_keymap_ui.draw_kmi` so the row matches the
    look-and-feel of Edit > Preferences > Keymap and supports full key
    capture / re-binding. Reads the live `_addon_keymaps` lists from each
    module rather than maintaining a parallel registry.
    """
    import rna_keymap_ui

    wm = context.window_manager
    kc = wm.keyconfigs.user
    if kc is None:
        layout.label(text="User keyconfig unavailable", icon='ERROR')
        return

    sources = (
        ("Viewport Screenshots (3D View)", viewport_screenshot._addon_keymaps),
        ("Node Screenshots (Node Editor)", node_screenshot._addon_keymaps),
        ("Clipboard / Orientation (3D View)", clipboard_paste._addon_keymaps),
        ("Saved Views (File Browser)", saved_file_views._addon_keymaps),
        ("Add GeoNode Object (3D View)", geonode_object._addon_keymaps),
        ("Viewport Navigation (Object Mode)", viewport_shortcuts._addon_keymaps),
        *power_panel.keymap_groups(),
    )

    for header, addon_kms in sources:
        if not addon_kms:
            continue
        col = layout.column()
        col.label(text=header, icon='DOT')
        for km, kmi in addon_kms:
            user_km = kc.keymaps.get(km.name)
            if user_km is None:
                continue
            user_kmi = user_km.keymap_items.from_id(kmi.id)
            if user_kmi is None:
                continue
            rna_keymap_ui.draw_kmi(
                ["ADDON", "USER", "DEFAULT"],
                kc, user_km, user_kmi, col, 0,
            )


_WIP_FOLDER_BACKUP_FILENAME = "no3d_asset_developer_wip_folder.json"


def _wip_folder_backup_path() -> str:
    """Return a user-config path that survives extension reinstalls."""
    config_dir = bpy.utils.user_resource("CONFIG")
    return os.path.join(config_dir, _WIP_FOLDER_BACKUP_FILENAME)


def _read_wip_folder_backup() -> str:
    try:
        with open(_wip_folder_backup_path(), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data.get("folder", "") if isinstance(data, dict) else ""
    except (OSError, json.JSONDecodeError):
        return ""


def _write_wip_folder_backup(folder: str) -> None:
    """Persist the folder outside extension preferences for reinstall safety."""
    try:
        path = _wip_folder_backup_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"folder": folder}, fh)
    except OSError:
        pass  # The primary AddonPreferences value remains available this session.


def _on_wip_folder_changed(self, context):
    """When the user picks a WIP folder in the N-panel, persist it to prefs.

    Writes the value into addon preferences AND saves userpref.blend
    immediately. Without the explicit save, a programmatic pref write only
    survives if "Auto-Save Preferences" flushes it on a clean exit — which is
    exactly how the WIP folder kept evaporating between sessions. No-ops when
    the value is unchanged (e.g. the lazy seed below), so prefs are only
    written on genuine user input.
    """
    addon = context.preferences.addons.get(__name__)
    if not (addon and hasattr(addon, "preferences")):
        return
    prefs = addon.preferences
    if prefs.export_library_path != self.no3d_wip_folder:
        prefs.export_library_path = self.no3d_wip_folder
    _write_wip_folder_backup(self.no3d_wip_folder)
    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        # Headless / restricted contexts: value is still set for this session;
        # persistence will catch up on the next interactive save.
        pass


def _seed_wip_folder_from_prefs():
    """One-shot timer: seed the WM prop from saved prefs once context is live.

    Register-time seeding (a baked StringProperty default) is unreliable —
    bpy.context is restricted while the addon registers, so the default came
    up empty and the panel looked reset every launch. A timer runs after
    startup with full context. Only fills an EMPTY WM prop; never overwrites
    a value the user set this session.
    """
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return 0.2  # context not ready yet, retry shortly
    addon = bpy.context.preferences.addons.get(__name__)
    saved = ""
    if addon and hasattr(addon, "preferences"):
        saved = addon.preferences.export_library_path or ""
    if not saved:
        saved = _read_wip_folder_backup()
    elif saved != _read_wip_folder_backup():
        # Migrate existing preference-only settings to the reinstall-safe copy.
        _write_wip_folder_backup(saved)
    if saved and not wm.no3d_wip_folder:
        wm.no3d_wip_folder = saved
    return None


def _register_identified_authoring_libraries():
    addon = bpy.context.preferences.addons.get(__package__)
    if not addon:
        return None
    prefs = addon.preferences
    try:
        library_roles.ensure_registration(
            bpy.context.preferences.filepaths.asset_libraries,
            library_roles.WIP_DISPLAY_NAME,
            bpy.path.abspath(prefs.export_library_path),
            library_roles.WIP_ID,
            "wip",
        )
        library_roles.ensure_registration(
            bpy.context.preferences.filepaths.asset_libraries,
            library_roles.STAGED_DISPLAY_NAME,
            bpy.path.abspath(prefs.public_library_path),
            library_roles.STAGED_ID,
            "staged",
        )
    except ValueError as exc:
        print(f"[NO3D Library Roles] {exc}")
    return None


def _register_wm_props():
    bpy.types.WindowManager.no3d_extraction_method = EnumProperty(
        name="Extraction Method",
        description="Which pipeline to use when writing per-asset .blend files",
        items=EXTRACTION_METHOD_ITEMS,
        default="DATABLOCK_WRITE",
    )
    bpy.types.WindowManager.no3d_wip_folder = StringProperty(
        name="WIP Folder",
        description=(
            "Working folder where assets are auto-extracted on Mark / Save / Rename. "
            "Each asset gets its own subfolder. Saved back to addon preferences."
        ),
        subtype="DIR_PATH",
        default="",  # seeded from prefs by _seed_wip_folder_from_prefs
        update=_on_wip_folder_changed,
    )
    bpy.types.WindowManager.no3d_wip_auto_mark = BoolProperty(
        name="Auto-sync on Mark",
        description="Auto-extract a new asset to the WIP folder the moment it is marked",
        default=True,
    )
    bpy.types.WindowManager.no3d_wip_auto_save = BoolProperty(
        name="Auto-sync on Save",
        description="On every file save, re-extract assets whose source has changed",
        default=True,
    )
    bpy.types.WindowManager.no3d_wip_auto_rename = BoolProperty(
        name="Auto-sync on Rename",
        description="When an asset is renamed, rename its WIP folder to match",
        default=True,
    )
    bpy.types.WindowManager.no3d_wip_recent_count = IntProperty(
        name="Recents Shown",
        description="How many of the most recently saved assets to list",
        default=3,
        min=1,
        max=30,
    )
    bpy.types.WindowManager.no3d_show_auto_sync = BoolProperty(default=False)


def _unregister_wm_props():
    for prop in (
        "no3d_extraction_method",
        "no3d_wip_folder",
        "no3d_wip_auto_mark",
        "no3d_wip_auto_save",
        "no3d_wip_auto_rename",
        "no3d_wip_recent_count",
        "no3d_show_auto_sync",
    ):
        try:
            delattr(bpy.types.WindowManager, prop)
        except AttributeError:
            pass


def register():
    # aspect_overlay must register FIRST: NO3D_AddonPreferences holds a
    # CollectionProperty pointing at NO3D_AspectCustomPreset, which is
    # owned by aspect_overlay. Registering prefs before the PropertyGroup
    # raises "register_class(...): expected a Property derived type".
    aspect_overlay.register()
    saved_file_views.register_types()
    bpy.utils.register_class(NO3D_AddonPreferences)
    _register_wm_props()
    bpy.app.timers.register(_seed_wip_folder_from_prefs, first_interval=0.0)
    bpy.app.timers.register(_register_identified_authoring_libraries, first_interval=0.1)
    note_manager.register()
    operators.register()
    node_screenshot.register()
    viewport_screenshot.register()
    editor_screenshot.register()
    header_screenshots.register()
    viewport_format.register()
    clipboard_paste.register()
    saved_file_views.register()
    geonode_object.register()
    viewport_shortcuts.register()
    power_panel.register()
    transparent_media.register()
    embed_staging.register()
    ui.register()
    stowaway_inspector.register()
    wip.register()
    wip_sync.register()
    public_library.register()
    repo_registration.register()


def unregister():
    power_panel.unregister()
    repo_registration.unregister()
    public_library.unregister()
    wip_sync.unregister()
    wip.unregister()
    stowaway_inspector.unregister()
    ui.unregister()
    embed_staging.unregister()
    transparent_media.unregister()
    viewport_shortcuts.unregister()
    geonode_object.unregister()
    saved_file_views.unregister()
    clipboard_paste.unregister()
    viewport_format.unregister()
    header_screenshots.unregister()
    editor_screenshot.unregister()
    viewport_screenshot.unregister()
    node_screenshot.unregister()
    operators.unregister()
    note_manager.unregister()
    if bpy.app.timers.is_registered(_seed_wip_folder_from_prefs):
        bpy.app.timers.unregister(_seed_wip_folder_from_prefs)
    if bpy.app.timers.is_registered(_register_identified_authoring_libraries):
        bpy.app.timers.unregister(_register_identified_authoring_libraries)
    _unregister_wm_props()
    bpy.utils.unregister_class(NO3D_AddonPreferences)
    saved_file_views.unregister_types()
    # aspect_overlay last: prefs (which referenced its PropertyGroup) is
    # already gone, so its draw handlers and the WM bool can be torn
    # down cleanly.
    aspect_overlay.unregister()


if __name__ == "__main__":
    register()
